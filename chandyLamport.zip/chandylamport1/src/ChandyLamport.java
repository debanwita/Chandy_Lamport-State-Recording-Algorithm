import java.util.*;

class Process
{
   Queue<String> send_queue;
   Queue<String> receive_queue;
   ArrayList<String> receive_queue2;
   ArrayList<Integer> receive_queue2_channels;
   int record_bit ;
   
   public Process()
    {
         send_queue = new LinkedList<String>(); 
         receive_queue = new LinkedList<String>();
         receive_queue2 = new ArrayList<String>();
         receive_queue2_channels = new ArrayList<Integer>();
         record_bit = 0;
    }
}

class Channel
{
    Queue<String> message_queue;
    int record_bit ;
    int name ;
    
    public Channel()
    {
        message_queue = new LinkedList<String>();
        record_bit = 0;
        //this.name = name ;
    }
   
}

class StateRecord
{
    Process process[] ;
    Channel channels[] ;
    int number_of_process ;
    int number_of_channels ;
    int adj[][] ;
	int initiator;
	ArrayList<Integer> state_record_order;
    
    public StateRecord()
    {
        System.out.println("\nEnter the number of processes: ");
        Scanner sc = new Scanner(System.in) ;
        number_of_process = sc.nextInt();
        
        state_record_order = (ArrayList<Integer>) new ArrayList<Integer>();
        

        process = new Process[number_of_process+1] ;
        
        for (int i= 1 ; i<= number_of_process ; i++)
            process[i]= new Process();
        
        number_of_channels =0;
        adj = new int[number_of_process+1][number_of_process+1];
        System.out.println("Enter the adjacency matrix");
        for(int i=1;i<=number_of_process ; i++)
        {
            for(int j=1;j<=number_of_process;j++)
            {
                adj[i][j]=sc.nextInt();
                if(adj[i][j]==1)
                    number_of_channels ++ ;
            }
        }
        channels = new Channel[number_of_channels+1] ;
    
        //print the adjacency matrix
        System.out.println("\nThe adjacency matrix is\n ");
        for(int i=1;i<=number_of_process ; i++)
        {
            for(int j=1;j<=number_of_process;j++)
            {
                System.out.print(adj[i][j] + "  ") ;
            }
            System.out.println();
        }
        
        System.out.println();
        //compute the channel names
        int k =1;
        for(int i=1;i<=number_of_process ; i++)
        {
            for(int j=1;j<=number_of_process;j++)
            {
                if(adj[i][j]==1)
                {
                    channels[k] = new Channel();
                    channels[k].name = i*10 + j ;
                    k ++;
                }
            }
        }
        
         //print the name of channels
        for (int i =1 ;i<=number_of_channels;i++)
        {
          System.out.println("Name of channel-" + i + "  " + channels[i].name);
         
        }
        
        //input the messages
        int message_counter=1;
        while(true)
        {
            System.out.println("\nDetails of Message " + message_counter++);
            System.out.println("--------------------");
            System.out.print("\tName :");
            String msg_name =sc.next();
         
            System.out.print("\tSender: ");
            int msg_sender=sc.nextInt();
         
            System.out.print("\tChannel Name: ") ;
            int cname = sc.nextInt();
            
            //insert the messages into the sender's queue
            process[msg_sender].send_queue.add(msg_name);
            for(k=1;k<=number_of_channels;k++)
            {
                if(cname==channels[k].name)
                    cname= k ;
            }
            channels[cname].message_queue.add(msg_name);
           
            System.out.print("Do you want to continue? (1/0):");
            int c = sc.nextInt();
            if(c==0)
                break;
        }
		
		System.out.print("\nEnter the initiator node : ");
		initiator = sc.nextInt();
		
		process[initiator].record_bit = 1;
		state_record_order.add(initiator);
        
		
		for(int i=1;i<=number_of_process;i++)
		{
			if(adj[initiator][i]==1)
			{
				int cname=initiator*10+i;
				for(k=1;k<=number_of_channels;k++)
				{
					if(channels[k].name==cname)
						break;
				}
				channels[k].message_queue.add("Marker");
			}
		}
		
    }
    
    public void chandylamport() throws IllegalStateException
    {
        /*//display exach process queue
        for(int i=1;i<=number_of_process;i++)
        {
            System.out.println("process -" + i + process[i].send_queue);
        }
        
        //display the channel queue
        for (int i=1;i<=number_of_channels;i++)
        {
            System.out.println("Channel name: " + channels[i].name + " :  " + channels[i].message_queue);
        }
        //System.out.println(state_record_order.get(0));*/
		
		while(true)
		{
			for(int i = 1;i<=number_of_channels;i++)
			{
				//display the process state and channel state and also the partial state_record_order
				display();

				if(channels[i].record_bit==0)
				{
					int channel_name = channels[i].name ;
					int receiver = channel_name % 10 ;
					//System.out.println(channel_name + "   " + "receiver: " + receiver);
					
					while(channels[i].message_queue.peek()!=null)
					{
						String M = channels[i].message_queue.remove();
						if(M.equalsIgnoreCase("marker"))
						{
							if(process[receiver].record_bit == 0) //1st time marker is received by the receiver
							{
								//record its own state
								process[receiver].record_bit = 1;
								state_record_order.add(receiver);
								//send marker to all its outgoing channels
								for(int l =1;l<=number_of_process;l++)
								{
									if(adj[receiver][l]==1) //find outgoing channels
									{
										int cname = receiver*10 + l;
										int m;
										for( m=1;m<=number_of_channels;m++)
										{
											if(channels[m].name == cname)
												break;
										}
										channels[m].message_queue.add("Marker");
									}
								}
								//indicate that this channel state is recorded
								channels[i].record_bit = 1;
								//make the channel state as empty
								channels[i].message_queue.clear(); // to remove the marker messages from the queue
								channels[i].message_queue.add("EMPTY");
								break;
								
							}
							else // process receives the marker for the 2nd time or more
							{
								//delete all the messages one by one from receive_queue2 and insert into the message_queue of the process
								if(process[receiver].receive_queue2.isEmpty()==false)
								{
									
									/*//access the entire arraylist
									for(int o=0; o<process[receiver].receive_queue2.size() ;o++)
									{
										System.out.print(process[receiver].receive_queue2.get(o) + "  ");
									}*/
									
									int size = process[receiver].receive_queue2.size();
									for(int s=0; s<size ;size--)
									{
										//System.out.println("Hii--Recieve channel:" + process[receiver].receive_queue2_channels.get(s) + "Receive Message: " + process[receiver].receive_queue2.get(s) + "channel" + i );
										if(process[receiver].receive_queue2_channels.get(s) == i) // messages were received through the same channel
										{
											//delete entry from the arraylist and add them to the channel list
											
											String m = process[receiver].receive_queue2.remove(s);
											process[receiver].receive_queue2_channels.remove(s);
											System.out.println("Deleted message is " + m);
											
											//add them to the channels queue
											channels[i].message_queue.add(m);
										}
									}
								}
								else
								{
									channels[i].message_queue.add("EMPTY");
								}
								//System.out.println("\n channels message queue becomes:" + channels[i].message_queue);
 								//make the channel state as recorded
								channels[i].record_bit = 1;
								break;
							}
						}
						else // M is a message
						{
							if(process[receiver].record_bit ==0)	// the process state is not yet recorded
							{
								// insert M into receive_queue
								process[receiver].receive_queue.add(M);
							}
							else // the process state was recorded earlier
							{
								//insert M into receive_queue2
								process[receiver].receive_queue2.add(M) ;
								process[receiver].receive_queue2_channels.add(i);
								//System.out.println("Byee-" + M + "  " + i);
								
								/*for(int o =0;o<process[receiver].receive_queue2.size();o++)
									System.out.println(process[receiver].receive_queue2.get(o) + "   " + process[receiver].receive_queue2_channels.get(o));*/
							}
						}
					}
				}
				
			}
			
			
			//display the process state and channel state and also the partial state_record_order
			display();
			
			int status = isAllRecorded();
			if(status == 1)
				break;
		}
		System.out.println("The state recording order");
		System.out.println(state_record_order);
    }
	
    public void display()
    {
    	//display the process state and channel state and also the partial state_record_order
		System.out.println("\n***Process states:***");
		System.out.println("-------------------------");
		for(int i =1 ;i<=number_of_process;i++)
		{
			System.out.println("\tProcess " + i);
			System.out.println("\t\tSend msg: ");
			if(process[i].send_queue.peek()!=null)
			{
				System.out.println("\t\t\t" + process[i].send_queue);
			}
			else
				System.out.println("\t\t\tEMPTY");
			
			System.out.println("\t\tReceive msg(before state recording): ");
			if(process[i].receive_queue.peek()!=null)
			{
				System.out.println("\t\t\t" + process[i].receive_queue);
			}
			else
				System.out.println("\t\t\tEMPTY");
			
			System.out.println("\t\tReceive msg(after state recording): ");
			if(process[i].receive_queue2.isEmpty()== false)
			{
				System.out.println("\t\t\t" + process[i].receive_queue2);
			}
			else
				System.out.println("\t\t\tEMPTY");
			
			System.out.println("\t\tRecord Bit: " + process[i].record_bit);
			System.out.println();
			
		}
		
		System.out.println("\n***Channel states:***");
		System.out.println("------------------------");
		for(int i=1 ;i<=number_of_channels;i++)
		{
			System.out.println("\tChannel " + channels[i].name);
			
			System.out.println("\t\tMessages: ");
			if(channels[i].message_queue.peek()!=null)
			{
				System.out.print("\t\t\t" + channels[i].message_queue);
			}
			else
				System.out.println("\t\t\tEMPTY");
			System.out.println("\n\t\t\tRecord Bit: " + channels[i].record_bit);
			System.out.println();
		}
		System.out.println("The state recording order");
		System.out.println(state_record_order);
		System.out.println("--------------------------------------------------------");
    }
	public int isAllRecorded() //returns true if all recorded else returns 0
	{
		int flag=1;
		for (int i =1;i<=number_of_process ; i++)
		{
			if(process[i].record_bit==0)
			{
				flag = 0;
				break;
			}
		}
		if(flag == 1) // all process states are recorded
		{
			flag = 1;
			for(int i =1;i<=number_of_channels;i++)
			{
				if(channels[i].record_bit==0)
				{
					flag =0;
					break;
				}
			}
		}
		return flag ;
	}
}
public class ChandyLamport {

    public static void main(String[] args) {
        StateRecord s = new StateRecord();
        s.chandylamport();
        //System.out.println(s.isAllRecorded());
    }
    
}
